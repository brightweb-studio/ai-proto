---
name: bw-prototype-system
description: >-
  Official standardized Bright Web Studio skill for designing and coding high-converting UX prototypes using the Untitled UI design system.
  Activate this skill whenever the user asks to create, develop, analyze, or enhance a prototype, landing page, website, page architecture, or copy for a Bright Web Studio client project.
---

# 🚀 Bright Web Prototype System (AI Studio OS v3.1)

This skill governs the end-to-end UX prototyping and coding lifecycle at Bright Web Studio: from initial discovery briefing and fact inventory to the 4 mandatory Stage-Gates with strict checkpoints (`[STOP]`) and a line-by-line QA audit.

---

## 🧭 Core Studio Rules and Philosophy

1. **🛑 No Immediate HTML Generation:** Prototype development strictly progresses through **4 mandatory Stage-Gates with an explicit stopping checkpoint (`[STOP]`) at each phase**.
2. **🔒 100% Pure Monochrome Standard:** The prototype is styled exclusively using Untitled UI's `Gray 25–950` monochrome scale (even if the client requested colors in the brief). Colors and accents are introduced by the designer during the UI Design stage.
3. **✂️ Ultra-Concise Copy ("Write, Cut"):** No lengthy paragraphs in cards (maximum 1 short sentence up to 8–10 words), H1 up to 6–8 words, bullets 2–5 words, CTA buttons 2–3 words.
4. **📊 Anti-AI Hallucination Standard (Claim ➔ Proof):** Never fabricate numbers, client logos, case studies, or awards. If data is unavailable, insert an explicit tag: `[MISSING INFORMATION: ...]`.
5. **📝 Two-Tiered Learning Logs:** During project work, corrections are logged locally in `PROJECTS/<project_name>/LEARNING_LOG.md`. Escalating to the global `LEARNING_LOG.md` is done only upon explicit user request.

---

## 🔄 4-Stage-Gate Workflow

```mermaid
flowchart TD
    A["Client Brief"] --> B["Stage 1: Content Readiness + 2-3 UX Strategies"]
    B -->|"[STOP] Awaiting Choice"| C["User Approves Strategy"]
    C --> D["Stage 2: Section Architecture (Sitemap) with Rationale"]
    D -->|"[STOP] Awaiting Sign-off"| E["User Approves Architecture"]
    E --> F["Stage 3: Concise Copywriting (Draft Copy) + Word Count Audit"]
    F -->|"[STOP] Awaiting Revisions"| G["User Approves Copy"]
    G --> H["Stage 4: Code Generation (HTML/CSS) + QA & Autofix Protocol"]
    H --> I["Prototype Delivery + QA Report (Score 100/100)"]
```

---

### 📌 STAGE 1. Fact Inventory & UX Strategy Gate

1. Conduct a brief analysis according to [references/CONTENT_SOURCE_PACK.md](./references/CONTENT_SOURCE_PACK.md).
2. Calculate the **Content Readiness Score (%)** and flag blockers:
   * If `< 60%` — block generation and supply a checklist of clarifying discovery questions.
   * If `>= 60%` — proceed with explicit `[MISSING INFORMATION]` placeholders.
3. Propose **2–3 fundamentally distinct UX strategies** (pain-point driven / product & metrics driven / social proof & case-study driven).
4. 🛑 **CHECKPOINT (`[STOP]`):** Post proposed strategies in chat and wait for user selection.

---

### 📌 STAGE 2. Architecture & Section Layout Gate

1. Build a step-by-step section wireframe (Hero, Bento Grid, interactive calculator, team, FAQ, 4-column footer, etc.).
2. For each section, specify:
   * **UX Function:** what user objection or goal it addresses (reduce anxiety, highlight ROI, provide proof);
   * **Rationale:** strategic reason for placing this block in this exact sequence;
   * **Pros 🟢 and Risks 🔴**.
3. Align with core principles in [references/UX_RULES.md](./references/UX_RULES.md) (1 section = 1 core message; avoid consecutive identical card grids).
4. 🛑 **CHECKPOINT (`[STOP]`):** Post architecture in chat and await sign-off.

---

### 📌 STAGE 3. Concise Copywriting (Draft Copy Gate)

1. Write complete page copy adhering to ultra-concise standards without Lorem Ipsum.
2. Enforce strict word budgets:
   * **Hero H1:** 6–8 words; **Lead subhead:** 1 line (up to 10–12 words);
   * **Card / Bento descriptions:** Maximum **1 concise sentence (8–10 words)** or 2–3 tags/chips;
   * **Bullet points:** 2–5 words; **Action buttons:** 2–3 words;
   * **Typography:** Non-breaking spaces `&nbsp;` for all short words (1–3 letters) and numerical values.
3. Perform a self-audit of word counts and append a **Word Count Audit** table.
4. 🛑 **CHECKPOINT (`[STOP]`):** Post copy deck in chat and wait for approval.

---

### 📌 STAGE 4. HTML/CSS Generation & QA Autofix Protocol (Prototype Gate)

1. **Establish Project File Structure in `PROJECTS/<project_name>/`:**
   * `LEARNING_LOG.md` — project-specific revision log.
   * `prototype_system.css` — local copy of `DESIGN_SYSTEM/prototype_system.css`.
   * `<project_name>_custom.css` — isolated stylesheet for all unique project styles.
   * `<project_name>_prototype.html` — clean semantic HTML without bloated inline `<style>` tags.
   * `index.html` — mirror copy of `<project_name>_prototype.html` for immediate preview.
2. **Mandatory Technical Requirements:**
   * Fixed `.prototype-spec-bar` (project title + structure jump dropdown + 390px toggle + dark/light theme switch).
   * Fully encapsulated 390px mobile simulator (header, hamburger menu, and content stay self-contained).
   * Functional interactive hamburger menu (☰ / ✕) with auto-close on anchor scroll.
   * Mobile buttons set to full width (`width: 100%`).
3. **Execute 5-Phase QA Editor-Auditor Protocol ([references/QA_AUDIT_INSTRUCTIONS.md](./references/QA_AUDIT_INSTRUCTIONS.md)):**
   * Inspect typography, Gray 25–950 monochrome adherence, 390px responsive fidelity, first FAQ accordion item expanded by default.
   * **If defects are found — immediately resolve them directly in the code (Autofix).**
   * Generate final QA Auditor report (Score 100/100) and deliver prototype.

---

## 📚 References & Guidelines

Detailed operational standards and guidelines are located in `references/`:
* 📘 **[references/PROTOTYPE_WORKFLOW_RULES.md](./references/PROTOTYPE_WORKFLOW_RULES.md)** — Complete step-by-step chat interaction and communication SOP.
* 📗 **[references/UX_PROTOTYPE_RULES.md](./references/UX_PROTOTYPE_RULES.md)** — Untitled UI coding standards, token scales, typography, and Anti-AI Slop heuristics.
* 📊 **[references/CONTENT_SOURCE_PACK.md](./references/CONTENT_SOURCE_PACK.md)** — Discovery briefing standard, 17 content categories, and Evidence Bank framework.
* 🛡️ **[references/QA_AUDIT_INSTRUCTIONS.md](./references/QA_AUDIT_INSTRUCTIONS.md)** — 5-phase line-by-line QA audit checklists and final report template.
* 🧠 **[references/UX_RULES.md](./references/UX_RULES.md)** — Foundational Bright Web persuasion UX methodology (AIDA, PASA, UX laws, choice psychology).

---

## 🎨 Design System & Resources

The Untitled UI design system core is maintained in `resources/design_system/`:
* 🎨 **[resources/design_system/prototype_system.css](./resources/design_system/prototype_system.css)** — Global immutable Untitled UI token core (Gray 25–950, radii, elevation shadows, typography).
* 📱 **[resources/design_system/ui_kit_showcase.html](./resources/design_system/ui_kit_showcase.html)** — Interactive catalog and showcase of all pre-built studio blocks, components, and layouts.
