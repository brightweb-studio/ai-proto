# QA AUDIT INSTRUCTIONS v1.0 (Inspector & Senior Editor Protocol)
### AI Studio OS • Official Prototype Inspection and Autofix Protocol

This document serves as a **directive operational standard for the AI agent acting in the role of "Editor-in-Chief & Quality Inspector"**.
Its mandate: prior to the final delivery of any prototype, execute a **comprehensive line-by-line audit of project files** (`.html` and `.css`), identify all deviations from studio rules, and **IMMEDIATELY RESOLVE THEM DIRECTLY IN CODE** (Autofix).

---

## 🎯 Role and Philosophy of the Editor-Auditor

1. **"Found ➔ Fixed in File" Directive:** The Auditor does not merely list errors in chat; they open the source code via editing tools and commit the fixes directly.
2. **Zero Tolerance for Deviations:** No prototype is deemed deliverable until it passes all 5 phases of this audit protocol with a score of 100 out of 100.
3. **"Write, Cut" Priority:** Any copy exceeding word budgets or containing corporate fluff is ruthlessly trimmed to 1 punchy sentence or structured chips.

---

## 📋 5-PHASE TOTAL AUDIT & AUTOFIX WORKFLOW

---

### PHASE 1. Copywriting & Typography Audit (Ultra-Concise Copy & Typography)

The Editor scans all textual content in the HTML markup against strict word limits:

| Element / Section | Strict Budget Limit | What the Auditor Inspects | Remediation Action |
|---|---|---|---|
| **H1 Heading** | **6–8 words** (max 2 lines) | Presence of active verb, absence of vague metaphors | Trim to 6–8 words, strip fluff |
| **Lead H1 (subhead)** | **Up to 10–12 words** (1 line) | Concrete business value, no repetition of entire page | Trim to 1 concise line |
| **H2 / H3 Headings** | **H2: 3–5 words / H3: 2–4 words** | Clarity, no compound clauses | Condense to core message |
| **Card Descriptions (Bento, Services, Benefits)** | **Max 1 short sentence (up to 8–10 words)** | 2+ sentences or long paragraphs in cards are forbidden! | Cut to 1 sentence or convert to 2–3 chips |
| **List Bullets** | **2–5 words per bullet** | Syntactic parallelism, extreme brevity | Remove filler adjectives, keep 2–4 words |
| **CTA Buttons** | **2–3 words** | Action-oriented verbs (*"Get...", "Calculate..."*) | Strip wordy labels, reduce to 2–3 words |
| **FAQ Answers** | **Up to 15–20 words** (1–2 short sentences) | Direct answers without philosophical introductions | Condense answer to 1–2 verified facts |

#### 🔍 Typography, Cleanliness, and Anti-Hallucination Checks (Claim ➔ Proof):
* [ ] **Zero Fabricated Facts (Evidence Bank):** Verify that all metrics, percentages, case studies, warranties, and timelines originate from the client brief. If exact figures are missing, the `[MISSING INFORMATION: ...]` tag must be present.
* [ ] **Non-Breaking Spaces (`&nbsp;`):** All short prepositions/articles (1–3 letters: *to, in, on, at, by, for, of, and, with, no*) and numerical metrics (*$3&nbsp;000, 15–50&nbsp;sq&nbsp;m, from&nbsp;4&nbsp;mo.*) must be bound with `&nbsp;`.
* [ ] **Headline Text Wrap:** All headings use `text-wrap: balance;`.
* [ ] **Zero Emojis:** Complete absence of standard emojis (🚀, 🔥, 👩‍🏫, ⭐, 🤝, 🔒). Clean SVG icons only.
* [ ] **Zero Inter-Word Bullets:** Interpunct dots `•` between inline words are forbidden (use `/` or distinct badge components).

---

### PHASE 2. Color Integrity Audit (100% Pure Monochrome Gray 25–950)

* [ ] **No Color Injections:** The auditor scans CSS and HTML for non-grayscale HEX, RGB, or HSL codes (blue, green, purple, orange, etc.).
* [ ] **Allowed Tokens:** Strictly Untitled UI grayscale variables (`--gray-25` through `--gray-950`).
* [ ] **Buttons & Accents:** Primary buttons must be high-contrast dark (`var(--gray-900)` or `#101828`); secondary buttons must be light gray or bordered transparent.
* [ ] **Dark Theme:** Dark mode background is dark graphite/slate (`#161922`), card background is (`#212530`). Harsh pitch black `#000000` is forbidden.

---

### PHASE 3. Layout, Spacing & 390px Mobile Simulator Audit

* [ ] **Fixed Spec Bar:** 
  - `position: fixed; top: 0; left: 0; width: 100%; z-index: 10000;`.
  - Left side: **Project Title Only** + **Section Dropdown (`<select class="spec-structure-select">`)**.
  - Right side: `Desktop / Mobile (390px)` viewport toggle and `☀️ / 🌙` theme switch.
* [ ] **Clean Navbar & Spacing Hierarchy:**
  - Layout begins directly with the navbar (top padding 12–16px).
  - Spacing between navbar and Hero is noticeably compact (16–20px) compared to standard section spacing (64–96px).
* [ ] **Content-Fit Badges:**
  - All badges, chips, and tags use `width: fit-content; align-self: flex-start;` (not stretched to 100%).
* [ ] **Encapsulated 390px Mobile Simulator (`body.view-mobile`):**
  - In mobile view, navbar, hamburger drawer, and all sections are contained **WITHIN the 390px phone container**.
* [ ] **Interactive Hamburger Menu (☰ / ✕):**
  - Functional mobile toggle opening the navigation drawer and automatically closing on anchor click.
* [ ] **Full-Width Buttons on Mobile:**
  - All mobile CTA buttons (in Hero, forms, cards) expand to `width: 100%` and stack vertically.

---

### PHASE 4. Conversion Architecture & Usability Audit

* [ ] **3-Second Hero Triad:** Hero immediately answers: *What is this? Who is it for? What is the core outcome?*.
* [ ] **No Dead-Ends:** Every section transitions smoothly to the next step or presents a clear action.
* [ ] **FAQ Accordion (NN/g Standard):** The primary/most critical FAQ question is expanded by default (`active` / `open`).
* [ ] **Lead Capture Form:** Maximum 2–3 required fields (Name + Phone/Email/Telegram) + embedded security microcopy inside the card.
* [ ] **Comprehensive 4-Column Footer:** Full site navigation map (Brand, Services, Social Proof, Contacts, Legal).

---

### PHASE 5. Autofix & Final QA Sign-Off

If any deviation is discovered during audit:
1. **Auditor immediately modifies the file** via code replacement tools.
2. **Synchronizes project files:** E.g., `<project>_prototype.html` ➔ `index.html`.
3. **Generates the final QA report** using the template below.

---

## 📝 Quality Inspector Final Report Template

```markdown
# 🛡️ Quality Inspector Audit Report: [<Project Name>]

### 📊 5-Phase Audit Results:

| Audit Phase | Evaluated Criteria | Status | Applied Autofixes |
|---|---|---|---|
| **1. Copy & Typography** | Word budgets (H1 <= 8 words, cards <= 10 words), &nbsp;, Zero Emoji | 🟢 Passed | [Condensed card descriptions, added &nbsp;] |
| **2. Monochrome Palette** | 100% Grayscale Gray 25–950, zero colored accents | 🟢 Passed | [Replaced non-gray tokens with pure monochrome] |
| **3. Layout & Mobile 390px** | Spec-bar, hamburger menu, encapsulation, full-width buttons | 🟢 Passed | [Verified in mobile simulator] |
| **4. UX & Conversion** | Hero triad, FAQ accordion (1st open), form <= 3 fields, 4-col footer | 🟢 Passed | [Expanded 1st FAQ item by default] |
| **5. File Synchronization** | Parity between <project>_prototype.html and index.html | 🟢 Passed | [Files identical] |

### 🔒 Final UX Quality Score: 100 / 100 🟢 EXCELLENT
The prototype has been fully verified, patched, and is ready for final delivery.
```
