# UX PROTOTYPE RULES v3.1 (Untitled UI Edition)
### AI Studio OS • Official Prototype Creation Standards for AI Agents

This document is a **mandatory directive for the AI agent**. Every prototype or web page generated at Bright Web Studio must rigorously conform to the standards below, the **global knowledge base [LEARNING_LOG.md](file:///Users/yurii_oleskiv/Documents/Antigravity%202.0/BW%20Agents/BW%20AI%20Studio%20/LEARNING_LOG.md)**, and the **project-specific local log `PROJECTS/<project_name>/LEARNING_LOG.md`**.

> 🔒 **TWO-TIERED AI LEARNING LOG SYSTEM:**
> 1. **Project Local Log (`PROJECTS/<project_name>/LEARNING_LOG.md`):** Must be created and maintained individually in every project directory. When developing a project, the agent reads its specific revision history and records iterative feedback and adjustments DIRECTLY HERE.
> 2. **Global Studio Log (`LEARNING_LOG.md` at root):** The cumulative studio knowledge base. Consulted at the start of any prototype. Entries from local project logs are promoted here **EXCLUSIVELY upon explicit user request or approval** in generalized format (typical problem + root cause + systemic "Always Do This" solution) for cross-project reuse.
> 3. **Manual Updates:** Log entries are edited directly using file modification tools (without running external python scripts).

---

## 0. Untitled UI Design System Architecture & Section Flexibility

### 0.1. Design System Structure & CSS Linking in Projects
* **Design System Core (`DESIGN_SYSTEM/`):** 
  - `DESIGN_SYSTEM/prototype_system.css` — Immutable design token core (Single Source of Truth).
  - `DESIGN_SYSTEM/ui_kit_showcase.html` — Component and layout catalog.
* **Project Organization (`PROJECTS/`):** 
  - Every project is housed in its dedicated folder `PROJECTS/<project_name>/` (e.g., `PROJECTS/edes/`).
  - Inside the root of the project folder, **create `LEARNING_LOG.md`** and **duplicate `prototype_system.css`**.
  - In HTML files, link via local relative paths:
    ```html
    <link rel="stylesheet" href="prototype_system.css">
    ```

> 🔒 **CRITICAL RULE: IMMUTABLE CORE CSS & STYLESHEET ISOLATION**
> 
> * **The core system file `DESIGN_SYSTEM/prototype_system.css` (and its local copy in the project) CANNOT BE MODIFIED.** It serves as the stable global token foundation.
> * **All bespoke, unique, or layout-specific styles for a new prototype** (custom components, unique page grids, specific animations, or modal windows) **must be authored strictly inside an isolated local `<name>_custom.css` file within the project folder**.
> * **It is forbidden** to store large `<style>` blocks in HTML markup, ensuring HTML remains clean and semantic.
> * All custom styles in `<name>_custom.css` must strictly leverage `var(--...)` tokens defined in `prototype_system.css`.

### 0.2. Clarification: Does the System CSS Limit Section Diversity?
* **No, the system CSS does not constrain layout variety.**
* **"Design Tokens + Flexible Layout" Philosophy:**
  1. `DESIGN_SYSTEM/prototype_system.css` provides **design tokens** (`Gray 25–900` palette, shadows `shadow-xs` to `shadow-2xl`, radii `6px–24px`, typography `Inter / Plus Jakarta Sans`, buttons, badges, form inputs, and the mobile simulator).
  2. **Page section layout is determined entirely by business goals and persuasion frameworks (AIDA / PASA):** The AI agent has full creative license to build any unique section (interactive calculators, Bento grids, configurators, timelines, carousels, pricing matrices, quizzes, multi-column blocks) styled with Untitled UI tokens (clean card backgrounds, subtle borders `var(--color-border-subtle)`, standardized radii, and balanced padding).

### 0.3. Stage-Gate Workflow
Generating the final HTML prototype immediately is strictly forbidden. The agent must progress through **4 sequential stages with an explicit stopping checkpoint ([STOP]) at each stage for user sign-off** (details in [RULES/PROTOTYPE_WORKFLOW_RULES.md](file:///Users/yurii_oleskiv/Documents/Antigravity%202.0/BW%20Agents/BW%20AI%20Studio%20/RULES/PROTOTYPE_WORKFLOW_RULES.md)):
1. **Stage 1 (Strategies):** Propose 2–3 alternative UX persuasion strategies -> [STOP]
2. **Stage 2 (Architecture & Rationale):** Propose section-by-section wireframe specifying UX functions, placement rationale, pros, and risks -> [STOP]
3. **Stage 3 (Copywriting & &nbsp;):** Draft complete copy deck without Lorem Ipsum, audit headings, CTAs, and bind non-breaking spaces `&nbsp;` -> [STOP]
4. **Stage 4 (HTML & QA):** Generate HTML prototype according to Untitled UI standards and audit against the QA checklist.

---

## 1. Untitled UI Anatomy & Component Tokens

### 1.1. Neutral Grayscale Tokens (Gray 25–900)
* `--uui-gray-25: #FCFCFD;` — Crisp card background accent;
* `--uui-gray-50: #F9FAFB;` — Canvas background (`--color-canvas`);
* `--uui-gray-100: #F2F4F7;` — Badges, switches, and icon backgrounds;
* `--uui-gray-200: #EAECF0;` — Subtle borders for cards and tables;
* `--uui-gray-600: #475467;` — Secondary descriptive copy;
* `--uui-gray-700: #344054;` — H4 headings and form labels;
* `--uui-gray-900: #101828;` — High-contrast H1–H3 headings and Primary buttons.

### 1.2. Corner Radii Scale (Untitled UI Radii)
* `radius-md: 8px;` — Small buttons, chips;
* `radius-lg: 12px;` — **Form inputs, selects**, standard cards;
* `radius-xl: 16px;` — Accordions, process cards;
* `radius-2xl: 20px;` — Feature bento containers, tables, navbars;
* `radius-3xl: 24px;` — Prominent dark CTA cards;
* `radius-full: 9999px;` — Badge groups (`.uui-badge-group`).

### 1.3. Form Inputs (Untitled UI Inputs)
* Height **48px**, radius **12px (`radius-lg`)**, padding **10px 16px**.
* Hierarchy: `.uui-form-group` + `.uui-form-label` (14px font-weight: 600 color: Gray 700) + `.uui-input` + smooth focus ring `focus:ring-4 focus:ring-gray-100`.

### 1.4. Full Multi-Column Footer Requirement
* **Rule:** Every prototype must conclude with a **comprehensive structured 4-column footer** (`.uui-footer-full`), not a thin one-liner:
  1. **Column 1 (Brand & Positioning):** Logo, concise mission/positioning statement (2–3 lines), legal company status, registration details.
  2. **Column 2 (Navigation / Solutions):** Links to core products, services, bundles, or programs.
  3. **Column 3 (Company & Proof):** Links to team, methodology, case studies, reviews, blog.
  4. **Column 4 (Contacts & Support):** Direct communication channels (Telegram, Instagram, phone, operating hours).
  5. **Bottom Row (Bottom Bar):** Copyright © 2026, Terms of Service, Privacy Policy.

### 1.5. Button UX & Full-Width Mobile Standards
* **Concise Button Labels (2–4 words):**
  - Button text must be punchy and actionable (e.g., *"Get Financial Model →"*, *"Calculate ROI"*, *"Lock in Estimate →"*).
  - Button labels must comfortably fit in a single line on both Desktop and Mobile (390px) without overflow or truncation.
* **Full-Width Buttons on Mobile (`width: 100%`):**
  - On smartphones (`body.view-mobile` and `@media (max-width: 768px)`), all CTA buttons (Hero CTAs, form submit buttons, modal buttons, and card actions) must expand to **100% width (`width: 100%`)** and stack vertically (`flex-direction: column; width: 100%;`). Narrow buttons surrounded by dead space on mobile are forbidden.

---

## 2. Anti-AI Slop Standards & Prohibitions

0. 🔒 **ABSOLUTE PROTOTYPE MONOCHROME (100% Pure Monochrome Standard — RULE #1):**
   * **Even if the client requested specific brand colors, color palettes, or accents in the brief (e.g., blue, purple, orange, green), the UX prototype is STILL built EXCLUSIVELY in monochrome (Grayscale Gray 25–950 from Untitled UI).**
   * **Categorically forbidden:** adding color styles, color gradients, colored buttons, colored badges, or tinted backgrounds during the prototyping phase.
   * **Why this is law:** During UX prototyping, stakeholder focus must remain 100% on information hierarchy, copy clarity, objection handling, and conversion flow rather than visual aesthetics. Brand colors are applied during the subsequent UI Design Concept phase.

1. ❌ **No Emojis (Rule 2.5):**
   * Standard emojis are prohibited (🚀, 🔥, 👩‍🏫, ⭐, 🤝, 🔒).
   * Use clean vector SVG icons (2px stroke) or clean typographic monograms (`JD`, `AB`, `TS`).
2. ❌ **No Inter-Word Bullets (Rule 2.6):**
   * Dividing inline words with interpunct dots `•` is prohibited. Use forward slashes `/` or distinct badge components.
3. ❌ **No Colored Accents or Gradients:**
   * Prototypes adhere strictly to Untitled UI neutral tokens (`--gray-25` through `--gray-950`). Zero non-gray color variables in CSS.
4. ❌ **No Broken Numerical Metrics:**
   * Numbers, currencies, and metrics must be locked with `white-space: nowrap`.
5. ❌ **No Empty One-Line Footers:**
   * The footer must always expand into a complete navigation sitemap.
6. ❌ **No Overflowing or Narrow Mobile Buttons:**
   * Multi-word button text causing horizontal overflow is prohibited, and narrow unstretched mobile buttons are banned.
7. ❌ **No Dangling Prepositions (Rule 2.7 Typography):**
   * Short prepositions and conjunctions (1–3 letters: *to, in, on, at, by, for, of, and, with, no*) must be joined to following words with a non-breaking space `&nbsp;`.
   * Currency metrics and ranges (*$3&nbsp;000, 15–50&nbsp;sq&nbsp;m, from&nbsp;4&nbsp;mo.*) must have non-breaking spaces `&nbsp;` or `white-space: nowrap`.
   * Headings must apply `text-wrap: balance;` for symmetrical multi-line rendering.

8. ✂️ 🔒 **ULTRA-CONCISE COPY STANDARD (WRITE, CUT — CONDENSE EVERYTHING POSSIBLE):**
   * **Core principle: LESS TEXT IS MORE POWERFUL.** Visitors scan pages in 2–3 seconds rather than reading prose. Anything that can be shortened, simplified, or converted to a number or badge **MUST BE CONDENSED**.
   * **Categorically forbidden:** bloated paragraphs, lengthy preambles, marketing fluff, and dense blocks of text inside cards.
   * **Word Budget Limits:**
     - **H1:** 6–8 words (maximum 2 lines).
     - **Lead H1:** 1 concise line (up to 10–12 words).
     - **H2:** 3–5 words; **H3:** 2–4 words.
     - **Card / Bento Body:** Maximum **1 short sentence (up to 8–10 words)** or 2–3 compact chips with metrics. Zero 3–4 line paragraphs in cards!
     - **List Bullets:** Strictly **2–5 words** per bullet.
     - **CTA Buttons:** **2–3 words** (e.g., *"Request Proposal →"*).
     - **FAQ:** 1–2 direct sentences (up to 20–25 words per answer).

   * **Contrast Benchmarks: "Before (Defect) ➔ After (Bright Web Standard)":**
     | Element | ❌ BEFORE (Too wordy / Fluff) | ✅ AFTER (Bright Web Concise Standard) |
     |---|---|---|
     | **Hero Lead** | *"Engineering precision for vehicles up to 10 years old. Full range of SRS Airbag restoration, electronics diagnostics, soundproofing, and custom interior wood veneering with certified work inspection certificates."* (29 words) | *"Airbag restoration, soundproofing, and interior styling with official warranties."* (9 words) |
     | **Service Card** | *"Factory installation of rear and 360 surround-view parking cameras with dynamic trajectories and high-definition nighttime performance via Sony sensors."* (20 words) | *"360° camera installation in OEM mounts with night vision."* (9 words) |
     | **Trust Block / USP** | *"No other auto workshop in the region delivers veneering at this level. We coat standard plastic interior trim with genuine wood veneer sheets."* (24 words) | *"Console and door trim wrapped in natural wood veneer."* (9 words) |
     | **Service Advantage** | *"You do not need to call friends or ride public transit. We partner with local taxi providers so your ride home from drop-off is 100% free."* (27 words) | *"Dropped off your car? We cover your taxi home."* (9 words) |
     | **List Bullet** | *"Installation of brand-new OEM or licensed European standard pyrotechnic squibs"* (10 words) | *"New licensed squibs"* (3 words) |
     | **FAQ Answer** | *"Yes, 100%. We never use cheap bypass resistors. We install brand-new certified squibs, repack the airbag module to factory specs, and recode the SRS ECU to original parameters. 2-year warranty."* (31 words) | *"Yes, we install factory squibs and reprogram the SRS ECU. 2-year warranty."* (12 words) |

---

## 3. Mandatory Responsive Layout, Hamburger Menu & Simulator

1. **Fixed Spec Bar (`.prototype-spec-bar`):**
   * The spec bar is **ALWAYS fixed at the top (`position: fixed; top: 0; left: 0; width: 100%; z-index: 10000;`)**.
   * **Left side:** Contains **EXCLUSIVELY project name** + **Page Structure Dropdown Navigator** for quick scrolling to sections:
     ```html
     <div class="spec-info">
       <span class="spec-project-name">EDES</span>
       <select class="spec-structure-select" onchange="if(this.value) location.href=this.value;">
         <option value="">Page Structure ▾</option>
         <option value="#section-hero">1. Hero (Main Screen)</option>
         <option value="#section-metrics">2. Network Metrics</option>
         <option value="#section-usp">3. Product USP</option>
         <!-- other sections -->
       </select>
     </div>
     ```
   * Long promotional sentences in place of the project title are forbidden.

2. **Encapsulated 390px Mobile Simulator (`body.view-mobile`):**
   * In mobile simulator mode (`body.view-mobile`), **the entire interface (Navbar, hamburger drawer, Hero, and all content) stays INSIDE the 390px container (`.uui-page-wrap`)**.
   * Menus or headers expanding outside the phone frame are prohibited.

3. **Interactive Mobile Hamburger Navigation:**
   * On mobile devices (`@media (max-width: 768px)`) and inside the mobile simulator (`body.view-mobile`), the navbar contains an **interactive hamburger toggle (☰ / ✕)**.
   * Clicking the hamburger opens the mobile drawer displaying navigation links and CTA button.
   * Clicking any link smoothly scrolls to the section and closes the drawer.

4. **Balanced Spacing & Anti-Overload Heuristics:**
   * **Compact Top Spacing Above Navbar:** Layout starts directly with `.uui-navbar`. Spacing above navbar is **compact (`var(--space-3)` to `var(--space-4)` / 12px–16px)**.
   * **Hero Offset:** Spacing between navbar and Hero **MUST be significantly smaller (`var(--space-4)` to `var(--space-5)` / 16px–20px) than standard section gaps (`var(--space-10)` to `var(--space-14)` / 64px–96px)**.
   * **Badges Hug Content (`width: fit-content; align-self: flex-start;`):** Badges and tags (`.uui-badge-group`, `.uui-section-tag`) must hug text length. Full-width stretched badges are forbidden.
   * **Badge Groups (`.uui-badge-group`):** On mobile, keep clean and single-line without broken multi-line borders.
   * **Buttons (`.uui-btn`):** Include sizing classes (`.uui-btn-md` / `.uui-btn-lg`) and expand to `width: 100%` on mobile.

5. **Mobile Simulator Frame (`body.view-mobile`):**
   * Switching to mobile wraps the layout into a centered **390px** smartphone casing with elevation shadow and subtle border.
   * Multi-column grids automatically stack to **1 column**.
   * All CTA buttons expand to **100% width (`width: 100%`)**.

---

## 4. Pre-Delivery Quality Checklist

Every AI agent must audit the prototype against these 11 points prior to completion, as codified in **[RULES/QA_AUDIT_INSTRUCTIONS.md](file:///Users/yurii_oleskiv/Documents/Antigravity%202.0/BW%20Agents/BW%20AI%20Studio%20/RULES/QA_AUDIT_INSTRUCTIONS.md)**:
- [ ] **0. 100% Pure Monochrome:** Grayscale Gray 25–950 only. Zero colors or tinted accents.
- [ ] **1. Ultra-Concise Copy:** No long paragraphs in cards (max 1 sentence or chips), H1 up to 8 words, bullets 2–5 words, buttons 2–3 words.
- [ ] **2. Fixed Spec Bar:** Contains only project name, section dropdown, device toggle, and theme switch.
- [ ] **3. Clean Navbar & Spacing Hierarchy:** Small top gap (12–16px), compact Hero offset (16–20px), standard section spacing (64–96px).
- [ ] **4. Content-Fit Badges:** `width: fit-content; align-self: flex-start;`.
- [ ] **5. 390px Encapsulation:** Navbar and drawer stay inside phone frame in simulator.
- [ ] **6. Functional Hamburger Menu:** Interactive toggle opening and closing navigation drawer.
- [ ] **7. Mobile Cleanliness:** No cluttered badges or dark blocks above header.
- [ ] **8. Non-Breaking Spaces (`&nbsp;`):** All short prepositions and numbers bound with `&nbsp;`.
- [ ] **9. Full-Width Mobile Buttons:** All action buttons expand to 100% width on phone.
- [ ] **10. Zero Emojis & Zero Inline Bullets:** Clean SVG icons only, no `•` between words.

> 🛡️ **Complete audit and autofix instructions:** refer to **[RULES/QA_AUDIT_INSTRUCTIONS.md](file:///Users/yurii_oleskiv/Documents/Antigravity%202.0/BW%20Agents/BW%20AI%20Studio%20/RULES/QA_AUDIT_INSTRUCTIONS.md)**.
