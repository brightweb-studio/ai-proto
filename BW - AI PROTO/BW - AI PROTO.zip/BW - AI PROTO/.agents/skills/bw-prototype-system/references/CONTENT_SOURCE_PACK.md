# 📊 CONTENT SOURCE PACK & EVIDENCE BANK PROTOCOL v1.0
### AI Studio OS • Bright Web Studio • Fact Inventory & Zero-Hallucination Standard

> 🔒 **CORE DIRECTIVE RULE (ZERO-HALLUCINATION BAN):**
> The AI agent is **STRICTLY FORBIDDEN** from inventing non-existent facts about the client's business:
> 1. **Forbidden to fabricate:** numbers, percentages, years of experience, client/project counts, names of founders/team members, partner/brand names, case studies, testimonials, certificates, licenses, pricing, warranty periods.
> 2. **If accurate data is missing from the brief:** AI must insert a standardized tag:
>    `[MISSING INFORMATION: <specifically what needs to be clarified with the client>]`
> 3. **Prior to developing architecture and copy (Stages 2 and 3):** AI must calculate the **Content Readiness Score (%)** and flag critical content blockers.

---

## 📦 1. CONTENT SOURCE PACK STRUCTURE (17 DATA CATEGORIES)

During the initial brief analysis or interview review, the AI agent categorizes discovery data across 17 distinct categories:

| # | Data Category | Includes | Priority | Action if Missing |
|---|---|---|---|---|
| **1** | **COMPANY** | Legal name, positioning, geography/city, market segment. | 🔴 Mandatory | Hard Blocker |
| **2** | **PRODUCT / SERVICES** | List of core services/products, flagship offering. | 🔴 Mandatory | Hard Blocker |
| **3** | **AUDIENCE (ICP)** | Target customer avatar, decision-maker persona (B2B/B2C). | 🔴 Mandatory | Hard Blocker |
| **4** | **PROBLEMS & PAINS** | Key pain points, anxieties, and frustrations from past experiences. | 🔴 Mandatory | Hard Blocker |
| **5** | **DESIRED OUTCOMES** | What end result the customer seeks (speed, safety, ROI). | 🔴 Mandatory | Hard Blocker |
| **6** | **VALUE PROPOSITION** | Primary offer (USP) distinguishing from direct competitors. | 🔴 Mandatory | Hard Blocker |
| **7** | **DIFFERENTIATORS** | Real technological, procedural, or service advantages. | 🟡 High Priority | `[MISSING INFORMATION]` |
| **8** | **PROCESS** | Step-by-step engagement workflow (how client receives service). | 🔴 Mandatory | Hard Blocker |
| **9** | **PRICING & TERMS** | Price ranges, payment terms (deposit/milestone), minimum deal. | 🟡 High Priority | `[MISSING: Pricing Range]` |
| **10** | **OBJECTIONS** | Top 3 major customer objections prior to purchase. | 🔴 Mandatory | Cross-check against brief |
| **11** | **CASES & PORTFOLIO** | Real projects, clients, scope of work, photography of delivery. | 🟡 High Priority | Insert case placeholder |
| **12** | **NUMBERS & METRICS** | Hard numbers (turnaround days, square footage, tonnage, years). | 🔴 Mandatory | Only confirmed metrics allowed |
| **13** | **REVIEWS & TESTIMONIALS**| Verified review quotes, client company names, stamps, roles. | 🟡 High Priority | `[MISSING: Verified Review]` |
| **14** | **PROOF & CERTIFICATES** | Official certificates, ISO/industry standards, licenses, contracts. | 🟡 High Priority | `[MISSING: Legal Proof]` |
| **15** | **COMPETITORS** | Who the client compares the offering against in the market. | 🟢 Optional | Supplementary context |
| **16** | **FAQ DATA** | Frequently asked customer questions from sales calls. | 🟡 High Priority | Extract from discovery call |
| **17** | **RESTRICTIONS / CONDITIONS** | Who they DO NOT work with, budget/geographic minimums. | 🔴 Mandatory | Include in lead qualifying filters |

---

## 🏦 2. EVIDENCE BANK TEMPLATE (VERIFIED FACTS REPOSITORY)

An Evidence Bank register of verified claims is maintained for every project. Any strong claim made on the website must have a backing entry:

```markdown
### 📋 EVIDENCE RECORD FORMAT:
- **CLAIM:** "In-house manufacturing and certified laminated safety glass"
- **EVIDENCE:** EN 14449:2014 certification, workshop photos, impact test inspection report.
- **SOURCE:** Client brief / Product catalog / Founder discovery interview.
- **CONFIDENCE:** High (100% verified) / Medium (needs wording refinement).
- **STATUS:** ✅ Approved for Public Use / ⚠️ Proof Required.
```

> ⚠️ **CLAIM ➔ PROOF PRINCIPLE:**
> If a claim lacks verifiable evidence (document, report, photo, or audited figure), AI may not generate superlative or absolute assertions. Instead, descriptive language without hyperbole must be used, or a `[MISSING PROOF]` tag must be inserted.

---

## 🧮 3. CONTENT READINESS SCORE ALGORITHM

Prior to initiating Stage 2 (Architecture) and Stage 3 (Copywriting), the AI agent runs an automated completeness check:

$$\text{Content Readiness Score} = \left( \frac{\text{Count of Filled Mandatory Fields}}{\text{Total Count of Mandatory Fields (10)}} \right) \times 100\%$$

### 🚦 Readiness Scale:
* **80% – 100% 🟢 READY TO DESIGN:** Critical data corpus gathered. Approved to advance to architecture and copy deck.
* **60% – 79% 🟡 CONDITIONAL PROCEED:** Minor gaps exist (e.g., exact pricing or 1 testimonial missing). Approved to build wireframe, but copy must include explicit `[MISSING INFORMATION]` tags.
* **< 60% 🔴 BLOCKED:** Critical data missing (lacking positioning, service breakdown, or target audience). Generation is blocked. AI must compile a **checklist of clarifying questions for the client**.

---

## 📋 4. CONTENT AUDIT REPORT TEMPLATE FOR CHAT

When AI reviews client discovery inputs at Stage 1, it provides this concise summary block:

```markdown
### 📊 Content Readiness Report: [Project Name]
* **Content Readiness Score:** [X]% 🟢 / 🟡 / 🔴
* **Critical Facts Collected:** [X] of 10
* **Critical Blockers:** [None / List of blockers]
* **Missing Information Tags [MISSING INFORMATION]:**
  - [Category 1]: Need to clarify [exact figure / certificate name]
  - [Category 2]: Need to provide [authentic photography / case description]
```
