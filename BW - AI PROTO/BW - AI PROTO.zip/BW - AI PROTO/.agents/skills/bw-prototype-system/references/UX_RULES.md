# UX RULES v1 (Senior Methodology)
### AI Studio OS • Bright Web Studio Operating Methodology

This document formalizes the internal UX, copywriting, and product design methodology of Bright Web Studio. Every rule is mandatory for designers, copywriters, and AI assistants during the development of text sketches, information architectures, interactive wireframes, prototypes, and high-converting web pages.

---

## 0. Sources & Foundational Methodology Corpus

To guarantee a senior-level standard of prototype architecture, this methodology synthesizes 5 foundational knowledge bases:

### 1. Bright Web Studio Empirical Production Portfolio
* **Source Scope:** Deep retrospective analysis of live commercial design and Webflow production projects (2024–2026), comparing high-converting interface patterns against solutions flagged with usability friction.
* **For AI Assistants:** Serves as the primary operational benchmark of battle-tested production experience, grounding decisions in proven user behavior and preventing the repetition of historical UX pitfalls.

### 2. "The Ideal Landing Page" (Alexey Petrochenkov, Evgeny Novikov)
* **Source Scope:** Foundational guide on landing page architecture and Conversion Rate Optimization (CRO). Encompasses the classical purchasing motivation framework (AIDA), input form contrast and usability standards, visual directional cues, friction minimization in lead capture, and Thank You Page UX.
* **For AI Assistants:** Used to engineer conversion blocks, lead capture forms, CTA elements, and micro-conversion funnels.

### 3. "Write, Cut" (Maxim Ilyakhov, Lyudmila Sarycheva)
* **Source Scope:** Definitive reference on the information style (infostyle) and authoritative copywriting. Mandates the elimination of marketing fluff, corporate jargon, evaluative adjectives, and passive voice. Insists on replacing adjectives with verified facts, utilizing active verbs, ensuring parallel list structures, and disclosing product limitations upfront.
* **For AI Assistants:** Serves as the strict editorial filter: purging clichés, transforming company-centric prose into reader-centric value, and enforcing ultra-concise word budgets.

### 4. Psychophysiological Laws of UX (lawsofux.com / Jon Yablonski)
* **Source Scope:** Compendium of empirical cognitive and ergonomic principles governing human perception:
  - **Hick's Law:** Decision-making time increases logarithmically with the number and complexity of choices.
  - **Fitts's Law:** The time required to reach a target is a function of the target distance and its physical dimensions.
  - **Jakob's Law:** Users spend most of their time on other websites, expecting your site to work like all the sites they already know.
  - **Miller's Law:** The average human short-term memory can retain only 7 (±2) chunks of information concurrently.
  - **Von Restorff Effect (Isolation Effect):** When multiple similar objects are present, the one that differs from the rest is most likely to be remembered and clicked.
  - **Peak-End Rule:** People judge an experience predominantly based on how they felt at its peak and at its conclusion.
* **For AI Assistants:** Provides the scientific justification for layout navigation, CTA button dimensions, pricing tier limits, and visual hierarchy.

### 5. Nielsen Norman Group Usability Research (nngroup.com / NN/g)
* **Source Scope:** Gold standard in human-computer interaction (Jakob Nielsen, Don Norman):
  - **F-Shaped Pattern:** Dominant web text scanning trajectory.
  - **Progressive Disclosure:** Cognitive load management technique revealing complex information only on demand.
  - **Mobile Usability & Thumb Zone:** Reachability mapping and touch-target standards.
  - **Accordion Accessibility:** Usability guidelines for collapsible content and FAQ accordions.
* **For AI Assistants:** Applied to calculate content scannability, responsive touch targets, and objection-handling layouts.

### 6. Untitled UI Global Design System (untitledui.com)
* **Source Scope:** Industry-leading component and token baseline for digital products and wireframes.
* **For AI Assistants:** **Mandatory visual standard for 100% of studio prototypes.** All wireframes, components, buttons, badge groups, metrics, cards, and tables must strictly adhere to the `Gray 25–900` neutral palette, radius scale, and styling of Untitled UI. The full catalog of design system rules is codified in [RULES/UX_PROTOTYPE_RULES.md](file:///Users/yurii_oleskiv/Documents/Antigravity%202.0/BW%20Agents/BW%20AI%20Studio%20/RULES/UX_PROTOTYPE_RULES.md).

---

## 1. Page Strategy

### 1.1. Mono-Scenario Intent
1. **Rule Name:** Mono-scenario target positioning.
2. **Rule:** Every page must be designed strictly around one specific user persona (Ideal Customer Profile) and subordinated to a single primary conversion objective.
3. **Rationale:** Attempting to satisfy multiple disparate audiences on a single landing page dilutes the core value proposition, introduces conflicting calls to action, and degrades conversion rates. When visitors fail to recognize themselves and their specific problem within the initial 3 seconds, they perceive the website as too generic and bounce.
4. **Critical Contexts:** Sub-landing pages for B2B solutions, course sales pages, residential real estate presentations, and targeted ad campaign funnels.
5. **Permissible Exceptions:** Corporate hub homepages with explicit top-level segmentation directing distinct audience segments into dedicated paths.
6. **Good Example:** A page tailored exclusively to web agency owners and freelancers, where every section addresses operational bottlenecks (cash flow chaos, team burnout, low retainers) leading to one action: downloading the operations system framework.
7. **Bad Example:** Trying to speak simultaneously to solopreneurs, angel investors, and enterprise conglomerates on one page without audience routing.
8. **AI Verification:** AI checks whether a singular ICP is defined and verifies that all on-page conversion mechanisms funnel into a uniform conversion event.

### 1.2. No Standard Filler Sections
1. **Rule Name:** Ban on cosmetic and boilerplate sections.
2. **Rule:** It is forbidden to insert a section merely because it is standard web practice (e.g., disconnected news carousels, context-free team grids, decorative galleries). Every section must fulfill a measurable persuasion objective in the conversion funnel.
3. **Rationale:** Superfluous blocks generate cognitive noise, cause scroll fatigue, scatter user attention, and spike bounce rates.
4. **Critical Contexts:** High-converting landing pages and focused promo sites.
5. **Permissible Exceptions:** Comprehensive corporate sites requiring dedicated news/blog architectures for organic SEO indexing.
6. **Good Example:** The page contains zero filler blocks: every screen sequentially presents technical differentiators, verified ROI metrics, integration workflows, and compliance certifications.
7. **Bad Example:** Adding a generic team grid and an outdated company blog feed from last year that adds zero credibility to enterprise B2B buyers.
8. **AI Verification:** AI interrogates every section: *"What explicit persuasion objective or objection does this section resolve?"*. If no strategic answer exists, the section is flagged for deletion.

### 1.3. Honesty & Constraint Disclosure
1. **Rule Name:** Transparency and constraint disclosure.
2. **Rule:** The page must honestly and prominently disclose working conditions, qualifying thresholds, and operational constraints (e.g., minimum budget from $1,000, 50% deposit required, only for businesses with >$100k ARR).
3. **Rationale:** Concealing terms to artificially inflate lead volume yields low-intent, unqualified inquiries and wastes team bandwidth. Transparent qualification filters out non-target leads and lifts target-lead trust by 200%.
4. **Critical Contexts:** B2B service firms, high-ticket products, financial services, selective academies.
5. **Permissible Exceptions:** Mass-market B2C e-commerce with standardized public retail pricing accessible to anyone.
6. **Good Example:** Clear disclosure of minimum invoice requirements, debtor criteria, and non-recourse vs. recourse factoring limits.
7. **Bad Example:** Hiding pricing and engagement criteria beneath an ambiguous "Order Now" button without context.
8. **AI Verification:** AI verifies the presence of disclaimers, eligibility criteria, or qualification thresholds (`Minimum Order / Requirement Threshold`) in the page copy.

---

## 2. Information Architecture

### 2.1. Progressive Disclosure (NN/g Standard)
1. **Rule Name:** Gradual complexity disclosure (Progressive Disclosure).
2. **Rule:** Information must flow from top-level value down to granular mechanics: first — what the user gets (business outcome), second — how it works (methodology/process), and finally — technical specifications and legal parameters.
3. **Rationale:** Overloading visitors with technical specifications upfront triggers anxiety before they understand the value proposition (NN/g usability benchmark).
4. **Critical Contexts:** Complex B2B platforms, fintech, engineering, architectural contracting.
5. **Permissible Exceptions:** Industrial spare-parts e-commerce catalogs where professional buyers search specifically for SKUs or engineering tolerances.
6. **Good Example:** Top screen highlights visual aesthetics, finished installations, and business benefits; structural engineering blueprints, load ratings, and certifications follow further down.
7. **Bad Example:** Opening screen immediately bombarding visitors with financial accounting formulas and regulatory codes without articulating simple business ROI.
8. **AI Verification:** AI models the information density across sections 1 to N, confirming that technical complexity scales progressively rather than regressing.

### 2.2. Jakob's Law Navigation
1. **Rule Name:** Navigational clarity based on Jakob's Law.
2. **Rule:** Navigation menus and interactive controls must adhere to users' established mental models and universal web conventions (logo left/center linking home, search/cart/contacts right, CTA prominent).
3. **Rationale:** Jakob's Law dictates that users spend the majority of their time on other sites, expecting your platform to behave consistently with familiar patterns.
4. **Critical Contexts:** Multi-page sites, product catalogs, and B2B portals.
5. **Permissible Exceptions:** Single-page micro-sites using anchor link navigation.
6. **Good Example:** Standard, clean category grouping by apparel type and production specs tailored to commercial apparel buyers.
7. **Bad Example:** Menu items named after internal company departments or opaque project codes, confusing visitors.
8. **AI Verification:** AI inspects menu labels for internal jargon and verifies standard naming patterns (`Services`, `Pricing`, `About`, `Contacts`).

### 2.3. Miller's Law (5–7 Item Limit)
1. **Rule Name:** Chunking selection choices via Miller's Law (5–7 options).
2. **Rule:** Items within top-level navigation, pricing tiers, or category groups must not exceed 5–7 elements at any single visual attention level.
3. **Rationale:** Human working memory holds an average of 7 (±2) discrete items. Exceeding this threshold induces cognitive overload and decision paralysis.
4. **Critical Contexts:** Navbar menus, pricing tiers, core service lists.
5. **Permissible Exceptions:** Broad e-commerce catalogs employing faceted multi-select filtering.
6. **Good Example:** Main navigation displaying exactly 4 focused anchors: Curriculum, Instructor, Pricing, Reviews.
7. **Bad Example:** Navbar showing 12 unorganized links without hierarchy, forcing extensive visual searching.
8. **AI Verification:** AI counts active links in navigation bars and pricing options (`count <= 7`).

---

## 3. Section Sequencing

### 3.1. Question-Answer Sequence
1. **Rule Name:** Answering the implicit question from the previous section.
2. **Rule:** Each consecutive section must directly answer the natural question or objection arising in the user's mind after viewing the preceding one.
3. **Rationale:** A landing page is a structured conversation. Disrupting the narrative flow triggers cognitive dissonance, prompting users to drop off.
4. **Critical Contexts:** Commercial landing pages and promotional funnels.
5. **Permissible Exceptions:** Visual design portfolios where visual rhythm takes precedence.
6. **Good Example:** Hero (What is this?) ➔ *User thinks: "How does it work?"* ➔ "3-Step Process" ➔ *User thinks: "What does it cost?"* ➔ Interactive Pricing Calculator ➔ *User thinks: "Is it legitimate?"* ➔ Proof & Certifications.
7. **Bad Example:** Hero followed immediately by reviews, then ingredients, then more reviews without connective tissue.
8. **AI Verification:** AI evaluates the simulated user question at the conclusion of each block, verifying that the next section provides a direct response.

### 3.2. Extended Conversion Funnel (AIDA / PASA)
1. **Rule Name:** Staged persuasion funnel (AIDA / PASA).
2. **Rule:** Section sequencing must follow a deliberate conversion progression: Attention (Capture focus) ➔ Interest (Hook with outcomes) ➔ Desire / Problem Agitation (Deepen urgency and pain) ➔ Proof / Trust (Mitigate skepticism with evidence) ➔ Action (Compelling CTA).
3. **Rationale:** Bypassing proof and credibility before demanding high-commitment action collapses funnel efficiency.
4. **Critical Contexts:** High-ticket B2B services, educational programs, enterprise software.
5. **Permissible Exceptions:** Commodity items with impulse demand or established brands with massive organic equity.
6. **Good Example:** Unpacking operational friction in agency workflows ➔ presenting the turnkey framework ➔ sharing verified graduate earnings ➔ enrollment CTA.
7. **Bad Example:** Jumping straight to a dry list of services with an instant "Order Now" button without articulating the core problem or providing proof.
8. **AI Verification:** AI audits the layout to confirm all 5 stages of the persuasion trajectory are represented.

---

## 4. Hero Section

### 4.1. 3-Second Hero Trinity
1. **Rule Name:** Hero must answer What / Who / Why within 3 seconds.
2. **Rule:** The Hero viewport must communicate three things within 3 seconds:
   - **What is this?** (Core product/service category).
   - **Who is it for?** (Target audience).
   - **Why should they care?** (Key measurable outcome/benefit).
3. **Rationale:** Visitors determine whether to stay or leave within 3–5 seconds. Ambiguous metaphors in Hero drop engagement by 30–50%.
4. **Critical Contexts:** Universal across all web products without exception.
5. **Permissible Exceptions:** None.
6. **Good Example:** "Premium Residential Complex in Lviv (What) for buyers who value absolute privacy (Who). Request floor plans and current pricing (Outcome/Action)."
7. **Bad Example:** "We craft digital wings for your brand's destiny" (vague, meaningless, lacks utility).
8. **AI Verification:** AI parses Hero H1, subhead, and imagery to extract `{Product}`, `{Audience}`, `{Value}`. If any token evaluates to `null`, the Hero is rejected.

### 4.2. H1 Visual Anchoring
1. **Rule Name:** Visual proof anchoring the H1 headline.
2. **Rule:** The H1 headline must be paired with an authentic visual representation of the product, interface, or physical deliverable.
3. **Rationale:** The brain processes imagery 60,000 times faster than text. Visual evidence instantly confirms page relevance.
4. **Critical Contexts:** Construction, 3D visualization, physical products, SaaS.
5. **Permissible Exceptions:** Abstract editorial art manifests (requires explicit user styling sign-off).
6. **Good Example:** High-fidelity 3D architectural reel embedded in the Hero instantly validating the studio's technical execution.
7. **Bad Example:** Generic stock vector geometric shapes that bear no resemblance to industrial equipment.
8. **AI Verification:** AI checks for contextual media in the Hero matching the H1 subject matter.

### 4.3. H1 Verb & Length Limit
1. **Rule Name:** H1 length limit (6–8 words) with active verbs.
2. **Rule:** H1 headings must not exceed 6–8 words, must feature a strong active verb, and render at 32px+ on desktop.
3. **Rationale:** Wordy headlines fail the 3-second comprehension test. Active verbs create immediate forward momentum.
4. **Critical Contexts:** Commercial web platforms.
5. **Permissible Exceptions:** Brand manifestos with prominent lead subheads.
6. **Good Example:** "Deploy the Freelance Operating System to scale past $3,000/mo." (active verb, 8 words, instant clarity).
7. **Bad Example:** An 18-word academic sentence with passive voice sprawling across 4 lines.
8. **AI Verification:** AI counts words in `<h1>` (`word_count <= 8`) and checks for an active verb.

### 4.4. Visual Directional Cues
1. **Rule Name:** Directional eye cues pointing toward the CTA.
2. **Rule:** Gaze direction of featured human subjects, graphic arrows, or structural vectors must orient toward the H1, offer, or primary CTA.
3. **Rationale:** Eye tracking proves visitors instinctively follow visual cues, increasing CTA interaction by 15–25%.
4. **Critical Contexts:** Hero viewports with lead capture forms or primary buttons.
5. **Permissible Exceptions:** Non-human abstract 3D visual backgrounds.
6. **Good Example:** Visual angles and graphic accents pointing directly into the estimate calculation form.
7. **Bad Example:** Model looking away toward the edge of the screen, pulling visual focus away from the CTA.
8. **AI Verification:** AI verifies directional layout alignment relative to conversion triggers.

---

## 5. Value Proposition

### 5.1. Measurable Value Proposition
1. **Rule Name:** Specificity over empty adjectives.
2. **Rule:** Value propositions must be stated using numbers, timeframes, or concrete deliverables rather than vague adjectives ("best", "premium", "reliable").
3. **Rationale:** Vague buzzwords induce banner blindness. Concrete metrics provide rational justification for purchase.
4. **Critical Contexts:** B2B proposals, fintech, investments, media buying.
5. **Permissible Exceptions:** Pure luxury emotional lifestyle branding.
6. **Good Example:** "Recoup ad spend in 14 days with a contracted minimum ROI of 250%."
7. **Bad Example:** "Delivering the most premium and flexible financing in the industry."
8. **AI Verification:** AI scans for stop-words: *"best", "ideal", "high-quality", "reliable"*. Flags occurrences lacking empirical data.

### 5.2. Facts Over Evaluative Adjectives
1. **Rule Name:** Replacing subjective claims with empirical facts.
2. **Rule:** Subjective assertions ("rapid delivery", "expert engineers", "seamless platform") are forbidden. Every claim must state an objective fact.
3. **Rationale:** Opinions prompt skepticism; audited facts establish undisputed credibility.
4. **Critical Contexts:** Differentiator lists, B2B services, guarantees.
5. **Permissible Exceptions:** None.
6. **Good Example:** Replacing "rapid factoring decisions" with "Credit limit decision in 3 hours based on 2 documents."
7. **Bad Example:** "Our specialists possess exceptional qualifications and deep experience."
8. **AI Verification:** AI detects qualitative adjectives and verifies whether empirical metrics (hours, days, percentages) back them up.

### 5.3. User-Centered Framing
1. **Rule Name:** Reader-benefit orientation ("You get..." over "We do...").
2. **Rule:** All copy must be framed from the perspective of user utility ("You receive", "Your business saves"), avoiding corporate self-adulation ("We are leaders", "We opened 5 offices").
3. **Rationale:** Visitors care about their own problems and outcomes, not company biographies.
4. **Critical Contexts:** All commercial sections and CTA buttons.
5. **Permissible Exceptions:** Legal "About Us" compliance disclosures.
6. **Good Example:** "Receive immediate payment upon shipping orders, eliminating cash flow crunches."
7. **Bad Example:** "We are an innovative outsourcing provider delivering exceptional business services."
8. **AI Verification:** AI measures pronoun and active verb balance, prioritizing reader-centric outcomes.

### 5.4. Strict Word & Density Budgets
1. **Rule Name:** Ultra-concise copy standard: condense everything possible.
2. **Rule:** The primary copywriting directive is **minimal words, maximum impact**. Anything that can be removed, simplified, or expressed as a metric or badge **must be condensed**. Long walls of text are banned:
   - **H1:** 6–8 words (1–2 lines).
   - **Lead H1:** 1 sentence (up to 10–12 words).
   - **H2:** 3–5 words; **H3:** 2–4 words.
   - **Card Body:** Maximum **1 short sentence (8–10 words)** or 2–3 compact parameter chips.
   - **Bullets:** Strictly **2–5 words** per bullet.
   - **CTA Buttons:** **2–3 words** (concise, action-driven).
   - **Table Cells:** 3–6 words.
   - **FAQ Answers:** 1–2 short sentences (up to 20–25 words).
3. **Rationale:** NN/g studies confirm that 79% of visitors scan pages in 2–3 seconds without reading paragraphs. Wordy blocks cause cognitive fatigue and lower conversions.
4. **Critical Contexts:** Commercial landing pages, mobile viewports, service cards.
5. **Permissible Exceptions:** Complete terms of service and privacy agreements in the footer.
6. **Good Example:** Metric chips (`120 min`, `2x / wk`, `5–6 students`) and 1 punchy sentence replacing dense paragraphs.
7. **Bad Example:** A 5-line paragraph of small text wedged inside a compact service card.
8. **AI Verification:** AI audits word counts per node and rejects elements exceeding allocated budgets.

### 5.5. Component & Element Minimalism (Hick's Law)
1. **Rule Name:** Component limits and visual minimalism.
2. **Rule:** The volume of similar visual elements per section is strictly capped:
   - Maximum **3 (rarely 4) cards** in a grid.
   - Maximum **3–4 steps** in a timeline/process.
   - Maximum **4–5 questions** in a landing page FAQ.
   - No deeply nested cards inside cards with redundant borders.
3. **Rationale:** Hick's Law shows decision time rises logarithmically with additional choices. Cluttered cards reduce comprehension.
4. **Critical Contexts:** Landing pages and responsive mobile screens.
5. **Permissible Exceptions:** E-commerce product catalogs with faceted filters.
6. **Good Example:** 3 tightly focused cards replacing 6 ambiguous blocks.
7. **Bad Example:** 8 crowded cards with double borders and nested boxes.
8. **AI Verification:** AI counts child items per layout container (max 3–4).

---

## 6. Call to Action (CTA)

### 6.1. Contextual Readiness CTA
1. **Rule Name:** Matching CTA commitment to user readiness.
2. **Rule:** CTA commitment must correspond to visitor temperature at that point in the page (Soft low-friction CTA near top, Hard high-intent CTA after proof).
3. **Rationale:** Demanding "Buy Now" on the Hero screen alienates cold visitors who haven't yet evaluated the value proposition.
4. **Critical Contexts:** Long sales cycle B2B, real estate, high-ticket coaching.
5. **Permissible Exceptions:** Impulse purchase commodities or high-intent search traffic.
6. **Good Example:** Hero offers "Download Program Syllabus", while the pre-footer offers "Reserve Your Seat".
7. **Bad Example:** High-friction "Book Custom Development" placed in Hero without pricing or scope context.
8. **AI Verification:** AI audits CTA progression from page top to bottom, forbidding premature high-friction Hard CTAs.

### 6.2. Action-Outcome Button Labeling
1. **Rule Name:** Button copy communicating user benefit.
2. **Rule:** Button text must convey the immediate benefit to the user ("Get Estimate Breakdown"), not the technical website operation ("Submit", "Send").
3. **Rationale:** "Submit" evokes giving up private data, while "Get..." triggers feelings of acquiring value.
4. **Critical Contexts:** All lead capture forms.
5. **Permissible Exceptions:** Universal authentication buttons ("Sign In").
6. **Good Example:** "Get Floor Plan Catalog".
7. **Bad Example:** Generic "Submit" or "Send".
8. **AI Verification:** AI flags forbidden verbs (*"Submit", "Send"*); enforces value verbs (*"Get", "Book", "Explore", "Calculate"*).

### 6.3. Fitts's Law & Full-Width Mobile CTA
1. **Rule Name:** CTA ergonomics via Fitts's Law and full mobile width.
2. **Rule:** Primary action buttons must provide ample click targets (height >=48px on desktop, >=52px on mobile). Button copy must be concise (2–4 words) to fit on one line on 390px screens. On mobile, all action buttons must expand to **100% width (`width: 100%`)**.
3. **Rationale:** Fitts's Law demonstrates that target acquisition speed improves with larger target areas. Full-width buttons maximize thumb tap targets on mobile.
4. **Critical Contexts:** Conversion buttons across all viewports.
5. **Permissible Exceptions:** Secondary inline text links in the footer.
6. **Good Example:** Punchy "Get Financial Model →" button at 52px height expanding to full width on mobile.
7. **Bad Example:** A tiny button with 7 words overflowing screen boundaries or a narrow button stranded next to empty space on mobile.
8. **AI Verification:** AI checks word count (`<= 4`) and enforces `width: 100%` on mobile breakpoints.

### 6.4. Von Restorff Effect (Pricing Tiers)
1. **Rule Name:** Visual isolation of the primary target tier.
2. **Rule:** When presenting 3 pricing or service options, the primary commercial tier must visually stand out (subtle border contrast, "Most Popular" badge, slightly elevated scale).
3. **Rationale:** The Von Restorff Effect shows that the visual anomaly captures 80% of initial cognitive focus.
4. **Critical Contexts:** Pricing matrices, service bundles, subscription tiers.
5. **Permissible Exceptions:** Unranked catalog listings with identical unit economics.
6. **Good Example:** The center tier highlighted with high-contrast styling and a "Best Value" badge.
7. **Bad Example:** 3 identical gray boxes with equal visual weight forcing users to read every line to find the sweet spot.
8. **AI Verification:** AI verifies that exactly one tier possesses distinct emphasis tokens (`accent class / badge / elevation`).

### 6.5. Form Container & Microcopy UX
1. **Rule Name:** High-contrast form container and trust microcopy.
2. **Rule:** Form containers must feature visual contrast against the canvas background, rounded input fields (12px), and reassuring privacy microcopy ("Your data is private. Zero spam.").
3. **Rationale:** Visual containment frames the task; privacy microcopy relieves data-leak anxiety, lifting completions by 10–18%.
4. **Critical Contexts:** All lead capture forms.
5. **Permissible Exceptions:** Inline single-field newsletter signups.
6. **Good Example:** Dedicated form card with prominent inputs and clear privacy assurance microcopy inside the card.
7. **Bad Example:** Borderless form inputs blending into a gray background with no privacy notice.
8. **AI Verification:** AI checks form container contrast and the presence of reassurance microcopy.

### 6.6. Peak-End Rule on Thank You Pages
1. **Rule Name:** High-value Thank You Page via the Peak-End Rule.
2. **Rule:** The post-submission confirmation screen must never be an empty dead-end "Thank You" screen. In accordance with the Peak-End Rule, it must deliver positive momentum and recommend a secondary micro-action (join community channel, download bonus asset, watch intro video).
3. **Rationale:** Post-submission marks the highest point of user engagement. A rewarding conclusion solidifies a positive brand memory.
4. **Critical Contexts:** All submission workflows.
5. **Permissible Exceptions:** None.
6. **Good Example:** "While we prepare your proposal, explore our recent case studies in Telegram."
7. **Bad Example:** A blank gray box reading "Submission received. Wait for contact."
8. **AI Verification:** AI checks for next-step CTAs on confirmation screens (`Success State / Page`).

---

## 7. Social Proof

### 7.1. Verified Social Proof
1. **Rule Name:** Verifiable credibility assets.
2. **Rule:** Social proof elements (reviews, customer logos, certifications) must incorporate verifiable credentials: LinkedIn links, authentic photos, company names, job titles, or video interviews.
3. **Rationale:** Anonymous reviews ("John, Manager") breed skepticism and degrade overall site credibility.
4. **Critical Contexts:** B2B, healthcare, investments, fintech.
5. **Permissible Exceptions:** Documented strict NDAs (marked "Enterprise B2B Client, $50M+ ARR, NDA").
6. **Good Example:** Client quotes paired with brand logos, headshots, and direct LinkedIn profile links.
7. **Bad Example:** Unattributed quotes without photos, full names, or verifiable organizations.
8. **AI Verification:** AI verifies verification attributes on testimonials: `{Author_Name}`, `{Role/Company}`, `{Photo/Link/Video}`.

### 7.2. B2B vs. B2C Proof Calibration
1. **Rule Name:** Proof alignment with decision psychology (B2B vs. B2C).
2. **Rule:** The proof format must match the buying decision model: B2B relies on company logos, ROI audits, and compliance; B2C relies on customer photos, ratings, and lifestyle feedback.
3. **Rationale:** B2B buyers mitigate career and company risk; B2C buyers seek emotional validation.
4. **Critical Contexts:** All commercial properties.
5. **Permissible Exceptions:** None.
6. **Good Example:** Displaying verified financial audits and enterprise client logos on a corporate site.
7. **Bad Example:** Using dry formal corporate letters on an adventure tourism site instead of vibrant traveler photos.
8. **AI Verification:** AI evaluates proof assets against business model taxonomy (B2B vs. B2C).

### 7.3. Visual Citation Contrast
1. **Rule Name:** Visual prominence of direct quotes.
2. **Rule:** Testimonials and founder quotes must feature distinct visual styling (card background, decorative quotation marks, large headshot, bolded takeaway metrics).
3. **Rationale:** Flat, uniform quote text blends into body copy and gets bypassed during scanning.
4. **Critical Contexts:** Founder quotes, customer endorsements.
5. **Permissible Exceptions:** None.
6. **Good Example:** Prominent quote card with stylized quotation accents and bolded outcome numbers.
7. **Bad Example:** Small gray italicized text on a gray background.
8. **AI Verification:** AI checks for styling distinctions on citation components.

---

## 8. Benefits & Features

### 8.1. Feature-to-Benefit Translation
1. **Rule Name:** "Feature ➔ Function ➔ Outcome" formula.
2. **Rule:** Every product feature must be articulated through a 3-step formula: **Feature ➔ What it does ➔ Concrete user benefit / time / profit**.
3. **Rationale:** Customers buy the personal outcome, not raw engineering specifications.
4. **Critical Contexts:** Engineering products, software tools, technical services.
5. **Permissible Exceptions:** Pure engineering specification sheets for certified technical personnel.
6. **Good Example:** "20V Brushless Motor (Feature) ➔ boosts runtime by 40% (Function) ➔ complete entire shift on one battery charge (Outcome)."
7. **Bad Example:** Listing steel grades and tolerances without explaining contractor benefits.
8. **AI Verification:** AI checks benefit cards for dedicated outcome statements answering "What does this mean for you?".

### 8.2. Claim-Proof Coupling
1. **Rule Name:** Immediate proof backing strong claims.
2. **Rule:** Bold claims must be substantiated with evidence within the exact same section.
3. **Rationale:** Unsubstantiated promises generate doubt and undermine trust.
4. **Critical Contexts:** Marketing agencies, contractor services, finance.
5. **Permissible Exceptions:** None.
6. **Good Example:** Backing an ROI claim with verified Google Ads / Meta Ads performance dashboard screenshots.
7. **Bad Example:** Promising "blood sugar normalization in 7 days" without citing clinical trials in that block.
8. **AI Verification:** AI pairs claim statements with backing `{Proof_Data}` components inside the same section container.

---

## 9. Case Studies & Portfolio

### 9.1. Narrative Case Structure
1. **Rule Name:** Structured case study storytelling.
2. **Rule:** Case study blocks must follow a structured narrative: **Baseline Pain ➔ Objective ➔ Delivered Solution ➔ Quantified Results**.
3. **Rationale:** Imagery proves aesthetic taste, but structured metrics prove business capability.
4. **Critical Contexts:** Design agencies, engineering firms, marketing partners.
5. **Permissible Exceptions:** Fashion modeling or wedding photography portfolios.
6. **Good Example:** Stating the client's initial design deficit, delivery turnaround, and resulting conversion uplift.
7. **Bad Example:** A grid of isolated mockup screenshots lacking context or measurable outcomes.
8. **AI Verification:** AI checks case study cards for `Point A (Before)`, `Delivered Solution`, and `Point B (Outcome)` data points.

### 9.2. Showcase Interactivity
1. **Rule Name:** Dynamic work demonstration.
2. **Rule:** Work samples should feature motion: video walk-throughs, before/after sliders, interactive prototypes, or micro-demos.
3. **Rationale:** Static flat mockups fail to convey motion dynamics, UI feel, and craftsmanship.
4. **Critical Contexts:** Webflow agencies, 3D studios, mobile apps, real estate.
5. **Permissible Exceptions:** Print publications and editorial packaging.
6. **Good Example:** Hover-triggered video playback and before/after comparisons.
7. **Bad Example:** Static low-resolution PNG screenshots.
8. **AI Verification:** AI checks for video or interactive preview components within the portfolio layout.

---

## 10. Objection Handling

### 10.1. Proactive Friction Removal
1. **Rule Name:** Proactive objection mitigation.
2. **Rule:** Primary buying objections (price, timing, delivery risk, integration friction) must be addressed directly within the page hierarchy.
3. **Rationale:** Unresolved doubts cause silent visitor abandonment.
4. **Critical Contexts:** High-ticket engagements, advance retainers, novel technologies.
5. **Permissible Exceptions:** Zero-commitment free lead magnets.
6. **Good Example:** Dedicated "What if our client delays payment?" section detailing credit insurance mechanisms.
7. **Bad Example:** Completely ignoring obvious delivery and financial risks.
8. **AI Verification:** AI identifies top 3 category objections and verifies presence of neutralizing sections.

### 10.2. Risk Reversal
1. **Rule Name:** Transparent risk elimination terms.
2. **Rule:** Risk mitigation must specify explicit terms (fixed-price scope, milestone billing, warranty periods).
3. **Rationale:** Eliminating downside risk lowers the barrier to initial contract execution.
4. **Critical Contexts:** Construction, custom Webflow development, professional services.
5. **Permissible Exceptions:** None.
6. **Good Example:** Clear 5-year hardware and glass warranty with free on-site service calls.
7. **Bad Example:** Ambiguous "warranty terms upon custom agreement".
8. **AI Verification:** AI checks for milestone schedules, guarantees, or warranty sections.

---

## 11. FAQ Section

### 11.1. Strategic FAQ Curation
1. **Rule Name:** Strategic objection resolution in FAQ.
2. **Rule:** FAQs must not serve as general encyclopedic repositories; they must strictly address questions that prevent visitors from converting.
3. **Rationale:** Trivia questions create distraction and introduce doubts.
4. **Critical Contexts:** Conversion-focused landing pages.
5. **Permissible Exceptions:** Customer support knowledge bases (Help Centers).
6. **Good Example:** Addressing "Will this work if we only have 2 designers?" or "Can we pay via corporate bank transfer?".
7. **Bad Example:** Listing generic medical trivia that fails to advance the buying decision.
8. **AI Verification:** AI filters FAQ entries against the criterion: *"Does this answer directly influence the purchase decision?"*.

### 11.2. Accordion Usability (NN/g Standard)
1. **Rule Name:** FAQ accordion with first item expanded by default.
2. **Rule:** FAQ sections must use an accordion layout with the first (most important) question opened by default (`state: open` / `active`).
3. **Rationale:** Keeping the primary item open reveals the interaction model and draws users into reading (NN/g standard).
4. **Critical Contexts:** Responsive mobile viewports.
5. **Permissible Exceptions:** When fewer than 3 brief questions fit comfortably without scrolling.
6. **Good Example:** First accordion item expanded, displaying answer and icon state (✕ / −).
7. **Bad Example:** Entire list collapsed or an unwieldy static wall of text.
8. **AI Verification:** AI checks default state configuration of first FAQ item (`active` / `open`).

---

## 12. Content Structure & Infostyle

### 12.1. Single-Thought Section
1. **Rule Name:** One section = one core message.
2. **Rule:** Every section must convey a single central message. Blending multiple unrelated topics in one block is forbidden.
3. **Rationale:** Mixed themes confuse cognitive focus and weaken comprehension.
4. **Critical Contexts:** Universal across all web layouts.
5. **Permissible Exceptions:** None.
6. **Good Example:** Dedicated 99.9% Uptime section, dedicated API section, dedicated Compliance section.
7. **Bad Example:** Merging service descriptions, legal contracts, and contact forms into one block.
8. **AI Verification:** AI extracts H2 titles and body points, verifying topical coherence.

### 12.2. F-Shaped Scanning Pattern (NN/g Standard)
1. **Rule Name:** Scannability optimized for F-pattern reading.
2. **Rule:** Content must accommodate F-pattern reading: the first 2–3 words of headings, opening sentences, and emphasized chips must convey 80% of section meaning.
3. **Rationale:** NN/g studies confirm 79% of users scan left margins and headings without reading complete sentences.
4. **Critical Contexts:** Text-dense corporate and B2B pages.
5. **Permissible Exceptions:** Literary essays and long-form narrative books.
6. **Good Example:** Bold metrics at the start of lines, active front-loaded verbs, concise hierarchy.
7. **Bad Example:** Monolithic unformatted text blocks lacking visual anchors.
8. **AI Verification:** AI verifies paragraph lengths (max 3–4 lines) and checks left-aligned visual anchors.

### 12.3. Active Voice & Plain Language
1. **Rule Name:** Active voice and plain language standards.
2. **Rule:** Write exclusively in the active voice ("We build", "You receive" rather than "Development is executed by our team"), purging corporate jargon and nominalizations.
3. **Rationale:** Passive voice sounds bureaucratic and detached. Plain language builds direct connection.
4. **Critical Contexts:** Commercial web platforms.
5. **Permissible Exceptions:** Official legal terms and privacy policies.
6. **Good Example:** "Recoup ad spend in 14 days" (active voice, punchy).
7. **Bad Example:** "The execution of complex advertising re-engineering operations is performed."
8. **AI Verification:** AI flags passive voice constructs and suggests direct active alternatives.

### 12.4. Parallel List Structure
1. **Rule Name:** Grammatical parallelism in lists.
2. **Rule:** All items within a list must share an identical grammatical structure (e.g., all starting with imperative verbs or all starting with nouns).
3. **Rationale:** Asymmetrical list items disrupt reading rhythm and reduce comprehension.
4. **Critical Contexts:** Feature bullets, process steps, course modules.
5. **Permissible Exceptions:** None.
6. **Good Example:** "Prepare workflow", "Build architecture", "Deploy framework" (all imperative verbs).
7. **Bad Example:** Item 1: "Design creation", Item 2: "We test code", Item 3: "Fast".
8. **AI Verification:** AI checks the grammatical parts of speech across sibling list items.

---

## 13. Visual Hierarchy

### 13.1. Dynamic Grid Layout
1. **Rule Name:** Layout rhythm and ban on repetitive card grids.
2. **Rule:** Do not stack identical card grids consecutively (no more than 2 consecutive card grids). Layouts must alternate: Bento grid, Split-screen, Timeline, Interactive Tabs.
3. **Rationale:** Repetitive grids induce scroll monotony and banner blindness.
4. **Critical Contexts:** Long landing pages (6+ sections).
5. **Permissible Exceptions:** E-commerce catalog listings.
6. **Good Example:** Alternating Bento grids, interactive carousels, and split-screen features.
7. **Bad Example:** 5 consecutive sections each consisting of an H2 over 3 identical icon cards.
8. **AI Verification:** AI maps section layout patterns and flags 3+ identical consecutive grids.

### 13.2. Visual Rhythm & Whitespace
1. **Rule Name:** Typographic scale contrast and whitespace breathing room.
2. **Rule:** Headings (H1, H2, H3) must maintain a clear scale ratio (1.5x–2x), with vertical section spacing ensuring breathing room (100px to 160px on desktop).
3. **Rationale:** Generous whitespace creates premium positioning and clarifies layout structure.
4. **Critical Contexts:** Corporate and high-end agency sites.
5. **Permissible Exceptions:** Dense engineering dashboards.
6. **Good Example:** Distinct headline hierarchy paired with balanced section padding.
7. **Bad Example:** Crowded sections where headings blend indistinguishably into body text.
8. **AI Verification:** AI evaluates heading size ratios and vertical margins/paddings.

---

## 14. Page Length

### 14.1. Length-to-Complexity Ratio
1. **Rule Name:** Matching page length to purchase complexity.
2. **Rule:** Page depth must correspond to decision friction and investment tier (4–6 sections for free webinars/simple items; 8–14 sections for B2B/real estate).
3. **Rationale:** Short pages fail to persuade on high-ticket purchases, while long pages fatigue low-commitment leads.
4. **Critical Contexts:** Architecture planning.
5. **Permissible Exceptions:** None.
6. **Good Example:** 5-section concise event landing page vs. 12-section comprehensive real estate presentation.
7. **Bad Example:** Bloated 15-section page for a free checklist download.
8. **AI Verification:** AI balances `Product_Complexity_Tier` against section count.

### 14.2. Content Efficiency
1. **Rule Name:** Zero fluff policy.
2. **Rule:** If removing a sentence or section does not hurt understanding or conversion, it must be removed.
3. **Rationale:** Respecting user time increases credibility and conversion rates.
4. **Critical Contexts:** All studio projects.
5. **Permissible Exceptions:** None.
6. **Good Example:** Clean, punchy messaging free of filler intros.
7. **Bad Example:** Rambling preambles detailing the history of an industry since the 19th century.
8. **AI Verification:** AI flags historical or generic trivia that does not actively sell the offer.

---

## 15. Mobile UX

### 15.1. Thumb Zone & Fitts's Law
1. **Rule Name:** Mobile-First Thumb Zone and >=48px touch targets.
2. **Rule:** Primary action buttons and form controls must sit within comfortable thumb reach (NN/g Thumb Zone) and measure >=48x48px (recommended 52px).
3. **Rationale:** Over 70% of studio traffic originates from mobile devices.
4. **Critical Contexts:** Responsive mobile viewports.
5. **Permissible Exceptions:** Desktop-only CAD or code tools.
6. **Good Example:** Ergonomic mobile nav, tall tap targets, sticky bottom CTA bar.
7. **Bad Example:** Tiny 24px links crowded together that cause accidental taps.
8. **AI Verification:** AI checks touch target dimensions (`min-height: 48px`, `min-width: 48px`).

### 15.2. Responsive Complexity Reduction
1. **Rule Name:** Adaptive layout restructuring for mobile.
2. **Rule:** Complex multi-column comparison tables and bento grids must collapse into single-column cards or horizontal carousels on mobile.
3. **Rationale:** Unintended horizontal page scrolling breaks the mobile user experience.
4. **Critical Contexts:** Complex comparison tables and pricing tiers.
5. **Permissible Exceptions:** None.
6. **Good Example:** Desktop comparison tables transforming into neat mobile cards.
7. **Bad Example:** Unadapted wide tables overflowing screen boundaries horizontally.
8. **AI Verification:** AI checks responsive collapse rules for layouts exceeding 2 columns.

### 15.3. Mobile UX Standards (Spec Bar, Burger Menu, Full-Width Buttons)
1. **Rule Name:** Header architecture, hamburger navigation, and full-width buttons.
2. **Rule:**
   - **Fixed Spec Bar:** The control bar (`.prototype-spec-bar`) is fixed at the top (`position: fixed; top: 0; left: 0; width: 100%; z-index: 10000;`). Left side holds **project title only** + **Page Structure Dropdown** navigator.
   - **Interactive Burger Navigation:** Mobile navbar includes a functional **hamburger toggle (☰ / ✕)** opening a clean navigation drawer with links and CTA button.
   - **Clean Spacing:** Desktop header-to-Hero gap is compact (16px–24px). On mobile, avoid bulky multi-line dark headers above navbar, keeping badges single-line.
   - **Full-Width Buttons (`width: 100%`):** All mobile CTA buttons expand to **100% container width (`width: 100%`)** and stack vertically.
3. **Rationale:** Burger navigation preserves access without cluttering the screen, balanced spacing prevents fatigue, and 100% button width maximizes tap ergonomics.
4. **Critical Contexts:** Mobile devices and 390px simulator mode.
5. **Permissible Exceptions:** None.
6. **Good Example:** Clean burger menu, compact spec bar with dropdown, full-width CTA buttons.
7. **Bad Example:** Bulky 4-line dark banner above navbar on mobile, broken multi-line badge, narrow off-center buttons.
8. **AI Verification:** AI checks for hamburger button, structure dropdown in spec bar, and `width: 100%` mobile buttons.

---

## 16. Conversion Logic

### 16.1. No Dead-End Policy
1. **Rule Name:** No dead ends.
2. **Rule:** Every page section must either lead into the next logical step or provide a clear call to action. The footer and pre-footer must include a closing CTA.
3. **Rationale:** Reaching the end of a scroll without an action forces users to exit or scroll aimlessly.
4. **Critical Contexts:** Universal across all pages.
5. **Permissible Exceptions:** None.
6. **Good Example:** Page concludes with a high-contrast inquiry form before the footer.
7. **Bad Example:** Page terminates abruptly with an unlinked copyright notice.
8. **AI Verification:** AI checks for a CTA component in the pre-footer section.

### 16.2. Micro-Conversion Traps
1. **Rule Name:** Low-friction micro-conversions for cold traffic.
2. **Rule:** For visitors unready for direct purchase, provide an alternative low-commitment conversion (download checklist, cost calculator, case study PDF via Telegram/Email).
3. **Rationale:** Only 2–5% of visitors convert immediately. Micro-conversions capture the remaining 95% of addressable traffic.
4. **Critical Contexts:** Real estate, high-ticket B2B, consulting.
5. **Permissible Exceptions:** Inexpensive impulse e-commerce items.
6. **Good Example:** Instant one-click download for architectural floor plans.
7. **Bad Example:** A single rigid "Contract 100 Tons" button without intermediate options.
8. **AI Verification:** AI checks for an opt-in or soft-conversion asset.

---

## 17. Anti-Patterns

### 17.1. Vague Cliché Ban
1. **Rule Name:** Ban on abstract marketing clichés.
2. **Rule:** Expressions lacking empirical proof are forbidden: *"individual approach", "high quality", "team of professionals", "flexible terms", "market leaders"*.
3. **Rationale:** Clichés reduce perceived brand value to zero and provoke reader skepticism.
4. **Critical Contexts:** Universal across all studio work.
5. **Permissible Exceptions:** None.
6. **Good Example:** "Credit limit decision in 3 hours based on 2 documents" instead of "individual approach".
7. **Bad Example:** 8 clichés packed into 3 sentences.
8. **AI Verification:** AI scans for banned buzzwords and flags them for factual replacement.

### 17.2. Friction-Heavy Forms
1. **Rule Name:** Ban on forms with 4+ mandatory fields.
2. **Rule:** Initial lead capture forms must not contain more than 2–3 required fields (e.g., Name + Phone/Telegram).
3. **Rationale:** Every additional field decreases form completion rates by 10–15%.
4. **Critical Contexts:** Lead capture forms on landing pages.
5. **Permissible Exceptions:** Detailed post-contact technical onboarding questionnaires.
6. **Good Example:** 2 fields: Name + Telegram.
7. **Bad Example:** Demanding tax IDs, company address, and annual revenue prior to an intro call.
8. **AI Verification:** AI counts input fields in conversion forms. Flags forms where `fields > 3`.

### 17.3. Color Injections in Wireframes Ban
1. **Rule Name:** Absolute prototype monochrome (100% Pure Monochrome Standard).
2. **Rule:** **Even if the client requested specific brand colors or palettes in the brief, the UX prototype is built EXCLUSIVELY in monochrome (Grayscale Gray 25–950 from Untitled UI).** Injecting color styles, color gradients, or tinted accents during wireframing is strictly forbidden.
3. **Rationale:** Colors distract stakeholders from evaluating information flow, copy clarity, and conversion architecture. Visual branding belongs strictly to the subsequent UI Design Concept stage.
4. **Critical Contexts:** 100% of studio prototypes without exception.
5. **Permissible Exceptions:** None.
6. **Good Example:** Wireframe executed entirely in Untitled UI Gray 25–950 tokens.
7. **Bad Example:** Adding purple or orange CTA buttons simply because a client mentioned brand colors.
8. **AI Verification:** AI audits CSS and HTML for non-grayscale color values, stripping non-compliant tokens immediately.

---

## UX QUALITY SCORE
### AI Studio OS • Operating Methodology

The UX Quality Score is Bright Web Studio's internal 100-point prototype auditing rubric.

### 1. Weighted Evaluation Criteria (Senior Edition)

| # | Criterion | Max Points | Description |
|---|---|---|---|
| **1** | **Hero & First Impression** | **15** | 3-second triad (What/Who/Why), H1 <=8 words with active verb, visual anchor, directional eye cues. |
| **2** | **Information Architecture & Flow** | **20** | 1 section = 1 idea, AIDA/PASA cascade, Q&A sequence, Jakob's Law navigation, Miller's Law (menu/tiers <=7). |
| **3** | **Value Proposition & Copy Precision** | **15** | Measurable metrics, replacing adjectives with facts, reader-centric framing ("You get..."), active voice. |
| **4** | **Visual Hierarchy & Grid Rhythm** | **15** | No repetitive card grids 3+ times in a row, diverse layouts (Bento, Split, Tabs), generous whitespace, Von Restorff tier emphasis. |
| **5** | **CTA Logic, Forms, Microcopy & Peak-End** | **15** | Readiness-calibrated CTA (Soft/Hard), outcome labels, Fitts's Law (height >=48px), form contrast (<=3 fields) + privacy microcopy, Peak-End Rule on Thank You Page. |
| **6** | **Mobile UX & Responsiveness** | **10** | Thumb Zone reachability, touch targets >=48px, adaptive table/grid collapse into sliders/cards. |
| **7** | **Social Proof, Transparency & Trust** | **10** | Verifiable credentials (photos, titles, logos), constraint disclosure, proactive objection handling, strategic FAQ with first item open. |
| | **Total** | **100** | |

---

### 2. Prototype Acceptance Scale & Verdicts

* **90 – 100 points — 🟢 EXCELLENT:** Prototype fully compliant with UX, CRO, and infostyle rules; approved for UI and Webflow production.
* **80 – 89 points — 🟡 READY:** Prototype accepted with minor polish items (minor copy or styling tweaks).
* **70 – 79 points — 🟠 REVISE:** Requires revision. Weak proof, repetitive grids, form friction, or passive voice. Revise wireframe.
* **< 70 points — 🔴 REJECT:** Prototype rejected. Complete overhaul required. Contains anti-patterns, clichés, or broken funnel logic.
